﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace salgados
{
    internal class Cliente
    {
        public string cpf { get; set; }
        public string nome { get; set; }
        public string cep { get; set; }
        public string endereco { get; set; }
        public string bairro { get; set; }
        public string cidade { get; set; }
        public string celular { get; set; }

        public List<Cliente> listacliente()
        {
            List<Cliente> li = new List<Cliente>();
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Cliente";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cliente c = new Cliente();
                c.cpf = dr["cpf"].ToString();
                c.nome = dr["nome"].ToString();
                c.cep = dr["cep"].ToString();
                c.endereco = dr["endereco"].ToString();
                c.bairro = dr["bairro"].ToString();
                c.cidade = dr["cidade"].ToString();
                c.celular = dr["celular"].ToString();
                li.Add(c);
            }
            return li;
        }
}
