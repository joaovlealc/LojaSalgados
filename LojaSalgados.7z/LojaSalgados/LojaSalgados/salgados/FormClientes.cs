﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace salgados
{
    public partial class FormClientes : Form
    {
        public FormClientes()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente();
                cliente.Inserir(txtCpf.Text,txtNome.Text,txtCep.Text,txtEndereco.Text,txtBairro.Text,txtCidade.Text,txtCelular.Text);
                MessageBox.Show("Cliente cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtBairro.Text = "";
                txtCidade.Text = "";
                txtCelular.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = new Cliente();
                cliente.Atualizar(txtCpf.Text, txtNome.Text, txtCep.Text, txtEndereco.Text, txtBairro.Text, txtCidade.Text, txtCelular.Text);
                MessageBox.Show("Cliente atualizado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtBairro.Text = "";
                txtCidade.Text = "";
                txtCelular.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                string cpf = txtCpf.Text.Trim();
                Cliente cliente = new Cliente();
                cliente.Exclui(cpf);
                MessageBox.Show("Cliente excluído com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> cli = cliente.listacliente();
                dgvCliente.DataSource = cli;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtCep.Text = "";
                txtEndereco.Text = "";
                txtBairro.Text = "";
                txtCidade.Text = "";
                txtCelular.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCpf.Text = "";
            txtNome.Text = "";
            txtCep.Text = "";
            txtEndereco.Text = "";
            txtBairro.Text = "";
            txtCidade.Text = "";
            txtCelular.Text = "";
        }

        private void btnCep_Click(object sender, EventArgs e)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://viacep.com.br/ws/" + txtCep.Text + "/json");
            request.AllowAutoRedirect = false;
            HttpWebResponse ChecaServidor = (HttpWebResponse)request.GetResponse();
            if(ChecaServidor.StatusCode != HttpStatusCode.OK)
            {
                MessageBox.Show("Servidor Indisponivel!");
                return;
            }
            using (Stream webStream = ChecaServidor.GetResponseStream())
            {
                if(webStream != null)
                {
                    using(StreamReader responseReader = new StreamReader(webStream))
                    {
                        string response = responseReader.ReadToEnd();
                        response = Regex.Replace(response, "[{},]", string.Empty);
                        response = response.Replace("\"", "");

                        String[] substrings = response.Split('\n');

                        int cont = 0;
                        foreach(var substring in substrings)
                        {
                            if(cont == 1)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                if(valor[0] ==" erro")
                                {
                                    MessageBox.Show("CEP não encontrado!");
                                    txtCep.Focus();
                                    return;
                                }
                            }

                            if(cont == 2)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtEndereco.Text = valor[1];
                            }

                            if (cont == 4)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtBairro.Text = valor[1];
                            }

                            if (cont == 5)
                            {
                                string[] valor = substring.Split(":".ToCharArray());
                                txtCidade.Text = valor[1];
                            }
                            cont++;
                        }
                    }
                }
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                string cpf = txtCpf.Text.Trim();
                Cliente cliente = new Cliente();
                cliente.Localiza(cpf);
                txtNome.Text = cliente.nome;
                txtCep.Text = cliente.cep;
                txtEndereco.Text = cliente.endereco;
                txtBairro.Text = cliente.bairro;
                txtCidade.Text = cliente.cidade;
                txtCelular.Text = cliente.celular;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void FormClientes_Load(object sender, EventArgs e)
        {
            Cliente cli = new Cliente();
            List<Cliente> cliente = cli.listacliente();
            dgvCliente.DataSource = cliente;
        }

        private void txtCpf_Leave(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\programas\\LojaSalgados-main\\LojaSalgados\\salgados\\DbSalgados.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("SELECT nome FROM Cliente WHERE cpf=@cpf", con);
            cmd.Parameters.AddWithValue("@cpf", SqlDbType.NChar).Value = txtCpf.Text;
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            int ctr = 0;
            while (dr.Read())
            {
                ctr++;
            }
            if (ctr == 1)
            {
                MessageBox.Show("Este CPF já existe em nosso menu!", "Registro repetido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtCpf.Text = "";
                txtCpf.Focus();
                con.Close();
            }
            else
            {

            }
        }

        private void dgvCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvCliente.Rows[e.RowIndex];
            txtCpf.Text = row.Cells[0].Value.ToString();
            txtNome.Text = row.Cells[1].Value.ToString();
            txtCep.Text = row.Cells[2].Value.ToString();
            txtEndereco.Text = row.Cells[3].Value.ToString();
            txtBairro.Text = row.Cells[4].Value.ToString();
            txtCidade.Text = row.Cells[5].Value.ToString();
            txtCelular.Text = row.Cells[6].Value.ToString();
        }
    }
}
