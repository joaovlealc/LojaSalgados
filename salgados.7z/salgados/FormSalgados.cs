﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace salgados
{
    public partial class FormSalgados : Form
    {
        public FormSalgados()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtID_Salgado.Text = "";
            txtNome_Salgado.Text = "";
            txtQuantidade.Text = "";
            txtValor.Text = "";
        }

        private void FormSalgados_Load(object sender, EventArgs e)
        {
            Salgado sal = new Salgado();
            List<Salgado> salgado = sal.listasalgado();
            dgvSalgado.DataSource = salgado;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                int qtde = Int32.Parse(txtQuantidade.Text);
                Salgado salgado = new Salgado();
                salgado.Inserir(txtNome_Salgado.Text, qtde, Convert.ToDecimal(txtValor.Text));
                MessageBox.Show("Salgado cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Salgado> sal = salgado.listasalgado();
                dgvSalgado.DataSource = sal;
                txtID_Salgado.Text = "";
                txtNome_Salgado.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";

                ClassConecta.FecharConexao();
            }
            catch(Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtID_Salgado.Text);
                int qtde = Int32.Parse(txtQuantidade.Text);
                Salgado salgado = new Salgado();
                salgado.Atualizar(id, txtNome_Salgado.Text, qtde, Convert.ToDecimal(txtValor.Text));
                MessageBox.Show("Salgado atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Salgado> sal = salgado.listasalgado();
                dgvSalgado.DataSource = sal;
                txtID_Salgado.Text = "";
                txtNome_Salgado.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtID_Salgado.Text);
                Salgado salgado = new Salgado();
                salgado.Exclui(id);
                MessageBox.Show("Salgado excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Salgado> sal = salgado.listasalgado();
                dgvSalgado.DataSource = sal;
                txtID_Salgado.Text = "";
                txtNome_Salgado.Text = "";
                txtQuantidade.Text = "";
                txtValor.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtID_Salgado.Text);
                Salgado salgado = new Salgado();
                salgado.Localiza(id);
                txtNome_Salgado.Text = salgado.nome;
                txtQuantidade.Text = Convert.ToString(salgado.quantidade);
                txtValor.Text = Convert.ToString(salgado.preco_unidade);
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void txtNome_Salgado_Leave(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\LojaSalgados\\LojaSalgados\\salgados\\DbSalgados.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("SELECT nome FROM Salgados WHERE nome=@nome",con);
            cmd.Parameters.AddWithValue("@nome", SqlDbType.NChar).Value = txtNome_Salgado.Text;
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            int ctr = 0;
            while (dr.Read())
            {
                ctr++;
            }
            if(ctr == 1)
            {
                MessageBox.Show("Este salgado já existe em nosso menu!", "Registro repetido!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome_Salgado.Text = "";
                txtNome_Salgado.Focus();
                con.Close();
            }
            else
            {

            }
        }

        private void dgvSalgado_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvSalgado.Rows[e.RowIndex];
            txtID_Salgado.Text = row.Cells[0].Value.ToString();
            txtNome_Salgado.Text = row.Cells[1].Value.ToString();
            txtQuantidade.Text = row.Cells[2].Value.ToString();
            txtValor.Text = row.Cells[3].Value.ToString();
        }
    }
}
