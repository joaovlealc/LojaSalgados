﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace salgados
{
    public partial class FormPedido : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\LojaSalgados\\LojaSalgados\\salgados\\DbSalgados.mdf;Integrated Security=True");
        public FormPedido()
        {
            InitializeComponent();
        }
        public void CarregaCbxCliente()
        {
            string cli = "SELECT * FROM Cliente ORDER BY nome";
            SqlCommand cmd = new SqlCommand(cli, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cli, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Cliente");
            cbxCliente.ValueMember = "cpf";
            cbxCliente.DisplayMember = "nome";
            cbxCliente.DataSource = ds.Tables["Cliente"];
            con.Close();
        }
        public void CarregaCbxSalgados()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            string pro = "SELECT * FROM Salgados ORDER BY nome";
            SqlCommand cmd = new SqlCommand(pro, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(pro, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Salgados");
            cbxCliente.ValueMember = "id";
            cbxCliente.DisplayMember = "nome";
            cbxCliente.DataSource = ds.Tables["Salgados"];
            con.Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormPedido_Load(object sender, EventArgs e)
        {
            if (cbxCliente.DisplayMember == "")
            {
                cbxSalgado.Enabled = false;
                txtId_Salgado.Enabled = false;
                txtQuantidade.Enabled = false;
                txtPreco.Enabled = false;
                dgvPedido.Enabled = false;
                btnAdicionar_Salgado.Enabled = false;
                btnExcluir_Salgado.Enabled = false;
                btnAtualizar_Salgado.Enabled = false;
                btnFinalizar_peddido.Enabled = false;
                txtPreco_Total.Enabled = false;
            }
            CarregaCbxCliente();
        }

        private void btnNovo_Pedido_Click(object sender, EventArgs e)
        {
            cbxSalgado.Enabled = true;
            CarregaCbxSalgados();
            txtId_Salgado.Enabled = true;
            txtQuantidade.Enabled = true;
            txtPreco.Enabled = true;
            dgvPedido.Enabled = true;
            btnAdicionar_Salgado.Enabled = true;
            btnExcluir_Salgado.Enabled = true;
            btnAtualizar_Salgado.Enabled = true;
            btnFinalizar_peddido.Enabled = true;
            txtPreco_Total.Enabled = true;
            dgvPedido.Columns.Add("Id", "Id");
            dgvPedido.Columns.Add("Salgados", "Salgados");
            dgvPedido.Columns.Add("Quantidade", "Quantididade");
            dgvPedido.Columns.Add("Valor", "Valor");
            dgvPedido.Columns.Add("Total", "Total");    
        }

        private void cbxSalgado_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(con.State == ConnectionState.Open)
            {
                con.Close();
            }
            SqlCommand cmd = new SqlCommand("SELECT * FROM Salgados WHERE Id=@Id", con);
            cmd.Parameters.AddWithValue("@Id", cbxSalgado.SelectedValue);
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtPreco.Text = dr["preco_unidade"].ToString();
                txtId_Salgado.Text = dr["Id"].ToString();
                txtQuantidade.Focus();
                dr.Close();
                con.Close();
            }
        }

        private void btnAdicionar_Salgado_Click(object sender, EventArgs e)
        {
            var repetido = false;
            foreach (DataGridViewRow dr in dgvPedido.Rows)
            {
                if (txtId_Salgado.Text == Convert.ToString(dr.Cells[0].Value))
                {
                    repetido = true;
                }
            }
            if (repetido == false)
            {
                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvPedido);
                item.Cells[0].Value = txtId_Salgado.Text;
                item.Cells[1].Value = cbxSalgado.Text;
                item.Cells[2].Value = txtQuantidade.Text;
                item.Cells[3].Value = txtPreco.Text;
                item.Cells[4].Value = Convert.ToDecimal(txtPreco.Text)*Convert.ToDecimal(txtQuantidade.Text);
                dgvPedido.Rows.Add(item);
                cbxSalgado.Text = "";
                txtId_Salgado.Text = "";
                txtQuantidade.Text = "";
                txtPreco.Text = "";
                decimal soma = 0;
                foreach (DataGridViewRow dr in dgvPedido.Rows)
                {
                    soma += Convert.ToDecimal(dr.Cells[4].Value);
                }
                txtPreco_Total.Text = Convert.ToString(soma);
            }
            else
            {
                MessageBox.Show("Salgado já consta na lista de pedido", "Item Repetido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPedido_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvPedido.Rows[e.RowIndex];
            cbxSalgado.Text = row.Cells[1].Value.ToString();
            txtId_Salgado.Text = row.Cells[0].Value.ToString();
            txtQuantidade.Text = row.Cells[2].Value.ToString();
            txtPreco.Text = row.Cells[3].Value.ToString();
        }

        private void btnAtualizar_Salgado_Click(object sender, EventArgs e)
        {
            int linha = dgvPedido.CurrentRow.Index;
            dgvPedido.Rows[linha].Cells[0].Value = txtId_Salgado.Text;
            dgvPedido.Rows[linha].Cells[1].Value = cbxSalgado.Text;
            dgvPedido.Rows[linha].Cells[2].Value = txtQuantidade.Text;
            dgvPedido.Rows[linha].Cells[3].Value = txtPreco.Text;
            dgvPedido.Rows[linha].Cells[4].Value = Convert.ToDecimal(txtPreco.Text) * Convert.ToDecimal(txtQuantidade.Text);
            cbxSalgado.Text = "";
            txtId_Salgado.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvPedido.Rows)
            {
                 soma += Convert.ToDecimal(dr.Cells[4].Value);
            }
            txtPreco_Total.Text = Convert.ToString(soma);
        }

        private void btnExcluir_Salgado_Click(object sender, EventArgs e)
        {
            int linha = dgvPedido.CurrentRow.Index;
            dgvPedido.Rows.RemoveAt(linha);
            dgvPedido.Refresh();
            cbxSalgado.Text = "";
            txtId_Salgado.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvPedido.Rows)
            {
                soma += Convert.ToDecimal(dr.Cells[4].Value);
            }
            txtPreco_Total.Text = Convert.ToString(soma);
        }

        private void txtQuantidade_Leave(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("quantidade",con);
            cmd.Parameters.AddWithValue("@Id", txtId_Salgado.Text);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader rd = cmd.ExecuteReader();
            int valor1 = 0;
            bool conversaoSucedida = int.TryParse(txtQuantidade.Text, out valor1);
            if (rd.Read())
            {
                int valor2 = Convert.ToInt32(rd["quantidade"].ToString());
                if (valor1 > valor2)
                {
                    MessageBox.Show("Não tem quantidade suficiente no estoque", "Estoque Insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtQuantidade.Text = "";
                    txtQuantidade.Focus();
                    con.Close();
                }
            }
            
        }

        private void btnFinalizar_peddido_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Pedido(cpf_cliente, valot_total,data_pedido) VALUES (@cpf_cliente,@valot_total,@data_pedido)", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@cpf_cliente", SqlDbType.NChar).Value = cbxCliente.SelectedValue;
            cmd.Parameters.AddWithValue("@valot_total", SqlDbType.Decimal).Value = Convert.ToDecimal(txtPreco_Total.Text);
            cmd.Parameters.AddWithValue("@data_pedido", SqlDbType.Date).Value = DateTime.Now;
            cmd.ExecuteNonQuery();
            string idpedido = " SELECT IDENT_CURRENT('Pedido')AS id_pedido";
            SqlCommand cmdpedido = new SqlCommand(idpedido, con);
            Int32 idpedido2 = Convert.ToInt32(cmdpedido.ExecuteScalar());
            foreach(DataGridViewRow dr in dgvPedido.Rows)
            {
                SqlCommand cmitems = new SqlCommand("INSERT INTO Itens_peido(id_pedido, id_produto, quantidade, valor_unidade,preco_total)VALUES (@id_pedido,@id_produto,@quantidade, @valor_unidade, @preco_total)", con);
                cmitems.CommandType = CommandType.Text;
                cmitems.Parameters.AddWithValue("@id_pedido", SqlDbType.Int).Value = idpedido2;
                cmitems.Parameters.AddWithValue("@id_produto", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                cmitems.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                cmitems.Parameters.AddWithValue("@valor_unidade", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                cmitems.Parameters.AddWithValue("@preco_total", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                cmitems.ExecuteNonQuery();
            }
            con.Close();
            dgvPedido.Rows.Clear();
            dgvPedido.Refresh();
            txtPreco_Total.Text = "";
            MessageBox.Show("pedido realiazado com sucesso!", "Venda", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
        
        }
    }
}
