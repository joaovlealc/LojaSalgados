﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace salgados
{
    internal class Salgado
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int quantidade { get; set; }
        public decimal preco_unidade { get; set; }

        public List<Salgado> listasalgado()
        {
            List<Salgado> li = new List<Salgado>();
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Salgados";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Salgado s = new Salgado();
                s.Id = (int)dr["Id"];
                s.nome = dr["nome"].ToString();
                s.quantidade = (int)dr["quantidade"];
                s.preco_unidade = Convert.ToDecimal(dr["valor"]);
                li.Add(s);
            }
            return li;
        }

        public void Inserir(string nome, int quantidade, decimal valor)
        {
            string num = valor.ToString();
            num = num.Replace(',', '.');
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Salgados(nome,quantidade,preco_unidade) VALUES ('"+nome+"','"+quantidade+"','"+preco_unidade+"')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();

        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Salgados WHERE Id='"+id+"'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                quantidade = (int)dr["quantidade"];
                preco_unidade = Convert.ToDecimal(dr["valor"]);
            }
        }

        public void Atualizar(int id, string nome, int quantidade, decimal preco_unidade)
        {
            string num = preco_unidade.ToString();
            num = num.Replace(',', '.');
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE Salgados SET nome='"+nome+"',quantidade='"+quantidade+"',valor='"+preco_unidade+"' WHERE ID = '"+id+"'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.obterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM Salgados WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}
